## Packages
framer-motion | Complex reveal animations and layout transitions
react-type-animation | Typing effect for the hero section text

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'JetBrains Mono'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
